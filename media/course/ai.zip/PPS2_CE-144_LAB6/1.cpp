#include<iostream>
using namespace std;
ostream& pos(ostream& temp)
{
    temp<<"Positive Number";
    return temp;
}
ostream& neg(ostream& temp)
{
    temp<<"Nagative Number";
    return temp;
}
int main()
{
    int a[5],i;
    for(i=0;i<5;i++)
    {
        cin>>a[i];
    }
    for(i=0;i<5;i++)
    {
        if(a[i]>0)
            cout<<a[i]<<" "<<pos<<endl;
        else if(a[i]<0)
            cout<<a[i]<<" "<<neg<<endl;
        else
            cout<<"0"<<endl;
    }
    return 0;
}
