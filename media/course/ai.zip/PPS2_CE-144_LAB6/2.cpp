#include<iostream>
#include<string>
#include<cstring>
using namespace std;
void rev(char s[])
{
    for(int i=strlen(s)-1;i>=0;i--)
    {
        cout<<s[i];
    }
    cout<<endl;
}
void rev(int a[],int n)
{
    for(int i=n-1;i>=0;i--)
    {
        cout<<a[i];
    }
}
int main()
{
    char str[100];
    cin>>str;
    int n,i;
    cin>>n;
    int a[n];
    for(i=0;i<n;i++)
        cin>>a[i];
    rev(str);
    rev(a,n);
}
