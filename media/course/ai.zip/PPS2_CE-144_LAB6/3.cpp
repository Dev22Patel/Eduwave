#include<iostream>
#include<string>
#include<cstring>
using namespace std;

struct emp
{
    string name;
    int id;
    int salary;
    string des;
};

void sort(emp *p,int n)
{
    for(int i=0;i<n-1;i++)
    {
        for(int j=0;j<n-1-i;j++)
        {
            if(p[j].salary>=p[j+1].salary)
            {
                emp temp=p[j];
                p[j]=p[j+1];
                p[j+1]=temp;
            }
        }
    }
}

int main()
{
    int n,i;
    cin>>n;
    emp *p=new emp[n];
    for(i=0;i<n;i++)
    {
        cin>>p[i].name>>p[i].id>>p[i].salary>>p[i].des;
    }
    sort(p,n);
    for(i=0;i<n;i++)
    {
        cout<<p[i].name<<" "<<p[i].id<<" "<<p[i].salary<<" "<<p[i].des<<endl;
    }
    return 0;
}
