#include <iostream>
using namespace std;
class Length
{
private:
  int totalInches;
public:
  void setLength (int ti)
  {
    totalInches = ti;
  }
  void displayFeetInches ()
  {
    int divisor = totalInches / 12, remainder = totalInches % 12;
    cout << divisor << "' " << remainder << "''" << endl;
  }
  void addLength (int totin)
  {
    totalInches += totin;
  }
  void addLength (int f, int i)
  {
    totalInches += 12 * f + i;
  }
  void addLength (Length & l)
  {
    totalInches += l.totalInches;
  }

};

int main ()
{
  Length len1;
  int t,x,p,f;
  cin>>t;
  len1.setLength (t);
  len1.displayFeetInches ();

  cout<<"Enter Inch To Add:: \n";
  cin>>x;
  len1.addLength(x);
  len1.displayFeetInches ();

  cout<<"Enter Inch And Feet To Add:: \n";
  cin>>f>>t;
  len1.addLength(f,t);
  len1.displayFeetInches ();

  Length len2;
  cout<<"Enter Other Object's Value To Add:: \n";
  cin>>p;
  len2.setLength (p);
  len1.addLength(len2);
  len1.displayFeetInches ();


  return 0;
}

