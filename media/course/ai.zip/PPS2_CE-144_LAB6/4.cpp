#include<iostream>
using namespace std;
class time
{
    int h,m,s;
    string mer;
    public:
    void sett(int h,int m,int s)
    {
        this->h=h;
        this->m=m;
        this->s=s;
    }
    void print()
    {
        cout<<h<<":"<<m<<":"<<s<<" "<<mer<<endl;
    }
    void chng()
    {
        if(h>12)
        {
            h-=12;
            mer="P.M.";
        }
        else
        {
            mer="A.M.";
        }
    }
}tm1;
int main()
{
    int h,m,s;
    cin>>h>>m>>s;
    tm1.sett(h,m,s);
    tm1.print();
    tm1.chng();
    tm1.print();
}

