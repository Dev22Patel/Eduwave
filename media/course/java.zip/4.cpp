#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;

class Product
{
    string product_name;
    float price;
    public:
    Product(string product_name,float price)  //parameterized constructor
    {
        this->product_name=product_name;
        this->price=price;
    }
    Product(const Product& p2)  //copy constructor
    {
        product_name=p2.product_name;
        price=p2.price*2;
    }
    void print()
    {
        cout<<product_name<<" ";
        printf("%0.2f",price);
    }
};

int main()
{
    string product_name;
    float price;
    cin>>product_name>>price;
    Product p(product_name,price);
    Product p1=p;  //creating a new object for copy constructor
    p1.print();
    return 0;
}
