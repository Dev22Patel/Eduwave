#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;
class Rectangle{
    int a[4],b[4];
    public:
    void initialize(int , int ,int );
    void top(int );
    void bottom(int );
    void left(int );
    void right(int );
    void whole_rect(int ,char );
    void print();
};
void Rectangle::initialize(int x,int y,int i)
{
        a[i]=x;
        b[i]=y;
}
void Rectangle::left(int x)
{
    for(int i=0;i<4;i++)
    {
        a[i]-=x;
    }
}
void Rectangle::right(int x)
{
    for(int i=0;i<4;i++)
    {
        a[i]+=x;
    }
}
void Rectangle::top(int x)
{
    for(int i=0;i<4;i++)
    {
        b[i]+=x;
    }
}
void Rectangle::bottom(int x)
{
    for(int i=0;i<4;i++)
    {
        b[i]-=x;
    }
}
void Rectangle::whole_rect(int x,char v)
{
       if(v=='T')
       {
           b[0]+=x;
           b[1]+=x;
       }
       else if(v=='B')
       {
           b[2]+=x;
           b[3]+=x;
       }
        else if(v=='L')
       {
           a[0]+=x;
           a[2]+=x;
       }
        else
        {
           a[1]+=x;
           a[3]+=x;
        }
}
void Rectangle::print()
{
    for(int i=0;i<4;i++)
    {
        cout<<a[i]<<" "<<b[i]<<endl;
    }
}
int main()
{
    Rectangle p;
    int x,y,n,unit;
    char c;
    for(int i=0;i<4;i++)
    {
      cin>>x>>y;
      p.initialize(x,y,i);
    }
    cin >> n;
  for(int i = 0; i < n; i++)
  {
    cin >> c;
 if(c!='A')
   {
     cin>>unit;
    switch(c)
    {
      case 'L':
        p.left(unit);
        break;
      case 'R':
        p.right(unit);
        break;
      case 'U':
        p.top(unit);
        break;
      case 'D':
        p.bottom(unit);
        break;
    }
  }
      else
      {
          char s,k;
          cin>>k>>s;
          cin>>unit;
          if(k=='I')
          {
               if(s=='B')
                  unit*=-1;
              else if(s=='L')
                unit*=-1;

          }
          else
          {
              if(s=='T')
                  unit*=-1;
              else if(s=='R')
                  unit*=-1;
          }
      switch(s)
    {
      case 'L':
        p.whole_rect(unit,s);
        break;
      case 'R':
        p.whole_rect(unit,s);
        break;
      case 'T':
        p.whole_rect(unit,s);
        break;
      case 'B':
        p.whole_rect(unit,s);
        break;
    }
      }
  }
    p.print();
    return 0;
}
