#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
using namespace std;

int bonus;
int bonus_e;
int bonus_te;
int bonus_m;

class Engineer
{
    int salary;
    string name;
    public:
    void setdata(int a,string b)
    {
       salary=a;
       name=b;
    }
    void print()
    {
        cout <<name<<" "<<salary<<endl;
    }
    void total_bonus()
    {
        bonus+=(0.25)*salary;
        bonus_e+=(0.25)*salary;
    }
};

class Manager
{
    int salary;
    string name;
    public:
    void setdata(int a,string b)
    {
        salary=a;
        name=b;
    }
    void print()
    {
        cout <<name<<" "<<salary<<endl;
    }
    void total_bonus()
    {
        bonus+=(0.3)*salary;
        bonus_m+=(0.3)*salary;
    }
};

class TeamLeader
{
    int salary;
    string name;
    public:
    void setdata(int a,string b)
    {
        salary=a;
        name=b;
    }
    void print()
    {
        cout <<name<<" "<<salary<<endl;
    }
    void total_bonus()
    {
        bonus+=(0.28)*salary;
        bonus_te+=(0.28)*salary;
    }
};

int main()
{
    int n;
    cin>>n;
    Engineer e;
    Manager m;
    TeamLeader t;
    for(int i=0;i<n;i++)
    {
        char c;
        cin>>c;
        if(c=='E')
        {
            int a;
            string b;
            cin>>a;
            getline(cin,b);
            e.setdata(a,b);
            e.print();
            e.total_bonus();
        }
        else if(c=='M')
        {
            int a;
            string b;
            cin>>a;
            getline(cin,b);
            m.setdata(a,b);
            m.print();
            m.total_bonus();
        }
        else
        {
            int a;
            string b;
            cin>>a;
            getline(cin,b);
            t.setdata(a,b);
            t.print();
            t.total_bonus();
        }
    }
    cout<<bonus_e<<" "<<bonus_te<<" "<<bonus_m<<" "<<bonus<<endl;
    return 0;
}
