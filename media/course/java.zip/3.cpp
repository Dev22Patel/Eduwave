#include <cmath>
#include <string>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;

class Person
{
    private:
    string name;
    int age;
    public:
    Person(string name,int age)
    {
        this->name=name;
        this->age=age;
    }
    Person()
    {

    }
    void print()
    {
        cout<<age<<" "<<name<<endl;
    }
};

class Family
{
    private:
    Person p[20];
    int member_count;
    public:
    Family()
    {
        member_count=0;
    }
    void add_member(string name,int age)
    {
        Person(name,age);
        p[member_count]=Person(name,age);
        member_count++;
    }
    void print()
    {
        for(int i=0;i<member_count;i++)
        {
            p[i].print();
        }
    }
};

int main()
{
    int n;
    cin>>n;
    Family f;
    for(int i=0;i<n;i++)
    {
        string name;
        int age;
        cin>>name>>age;
        f.add_member(name,age);
    }
    f.print();
    return 0;
}
