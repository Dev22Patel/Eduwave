#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>

using namespace std;
class Point{
    int x,y;
    public :
   void initialize(int x,int y){
       this->x = x;
       this->y = y;
   }
   friend class Rectangle;
};
class Rectangle{
    Point p[4];
    public:
    void initialize(int , int ,int );
    void top(int );
    void bottom(int );
    void left(int );
    void right(int );
    void whole_rect(int ,char );
    void print();
};
void Rectangle::initialize(int x,int y,int i)
{
        p[i].initialize(x,y);
}
void Rectangle::left(int x)
{
    for(int i=0;i<4;i++)
    {
        p[i].x-=x;
    }
}
void Rectangle::right(int x)
{
    for(int i=0;i<4;i++)
    {
        p[i].x+=x;
    }
}
void Rectangle::top(int x)
{
    for(int i=0;i<4;i++)
    {
        p[i].y+=x;
    }
}
void Rectangle::bottom(int x)
{
    for(int i=0;i<4;i++)
    {
        p[i].y-=x;
    }
}
void Rectangle::whole_rect(int x,char v)
{
       if(v=='T')
       {
           p[0].y+=x;
           p[1].y+=x;
       }
       else if(v=='B')
       {
           p[2].y+=x;
           p[3].y+=x;
       }
        else if(v=='L')
       {
           p[0].x+=x;
           p[2].x+=x;
       }
        else
        {
           p[1].x+=x;
           p[3].x+=x;
        }
}
void Rectangle::print()
{
    for(int i=0;i<4;i++)
    {
        cout<<p[i].x<<" "<<p[i].y<<endl;
    }
}
int main()
{
    Rectangle p;
    int x,y,n,unit;
    char c;
    for(int i=0;i<4;i++)
    {
      cin>>x>>y;
      p.initialize(x,y,i);
    }
    cin >> n;
  for(int i = 0; i < n; i++)
  {
    cin >> c;
 if(c!='A')
   {
     cin>>unit;
    switch(c)
    {
      case 'L':
        p.left(unit);
        break;
      case 'R':
        p.right(unit);
        break;
      case 'U':
        p.top(unit);
        break;
      case 'D':
        p.bottom(unit);
        break;
    }
  }
      else
      {
          char s,k;
          cin>>k>>s;
          cin>>unit;
          if(k=='I')
          {
               if(s=='B')
                  unit*=-1;
              else if(s=='L')
                unit*=-1;

          }
          else
          {
              if(s=='T')
                  unit*=-1;
              else if(s=='R')
                  unit*=-1;
          }
      switch(s)
    {
      case 'L':
        p.whole_rect(unit,s);
        break;
      case 'R':
        p.whole_rect(unit,s);
        break;
      case 'T':
        p.whole_rect(unit,s);
        break;
      case 'B':
        p.whole_rect(unit,s);
        break;
    }
      }
  }
    p.print();
}