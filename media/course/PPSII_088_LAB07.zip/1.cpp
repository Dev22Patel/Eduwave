#include<iostream>
#include<string>
using namespace std;
class emp{
    string name;
    int employeeid;
    string designation;
    float salary;
    public:
    void setdata(string name,int employeeid,string designation, float salary)
    {
        this->name=name;
        this->employeeid=employeeid;
        this->designation=designation;
        this->salary=salary;
    }
    void sort_emp(emp *emp_detail);
    void getdata_after_sorting()
    {
        cout<<name<<" "<<employeeid<<" "<<designation<<" "<<salary<<endl;
    }
};
void emp:: sort_emp(emp *emp_details,int n)
{
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n-i-1;j++)
        {
            if((*(emp_details+j).salary)>(*(emp_details+j+1).salary))
            {
                emp temp=*(emp_details+j);
                *(emp_details+j)=*(emp_details+j+1);
                *(emp_details+j+1)=temp;
            }
        }
    }
}
int main()
{
    int n,id;
    float salary;
    string name,desig;
    emp temp;
    cin>>n;
    emp *emp_details=new emp[n];
    for(int i=0;i<n;i++)
    {
        cin>>name>>id>>desig>>salary;
        (emp_details+i).setdata(name,id,desig,salary);
    }
    temp.sort_emp(emp_details,n);
    for(int i=0;i<n;i++)
       (emp_details+i).setdata_after_sorting();
    return 0;
}