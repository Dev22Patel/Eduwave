#include <iostream>
#include <string>
using namespace std;
/*
Write your code here
*/
double volume(double a,double b,double c)
{
    double vol2=a*b*c;
    return vol2;
}

double volume(double l)
{
    double vol=l*l*l;
    return vol;
}

int main()
{
  	string shape;
    double d1, d2, d3;

  	std::cin >> shape;
  	if('e' == shape[3])
    {
      	std::cin >> d1;
      	std::cout << volume(d1);
    }
  	else
    {
      	std::cin >> d1 >> d2 >> d3;
      	std::cout << volume(d1, d2, d3);
    }

    return 0;
}
