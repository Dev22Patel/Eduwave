#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


double area(double l)
{
return l*l;
}
float area(float l,float b)
{
return l*b;
}
float area(float r)
{
return 3.14*r*r;
}



int main()
{
    string shape;
    cin>>shape;
    if(shape[2]=='u')
    {
        double l;
        cin>>l;
        cout<<area(l);
    }
    else if(shape[2]=='c')
    {
        float l,b;
        cin>>l>>b;
        cout<<area(l,b);
    }
    else
    {
        float r;
        cin>>r;
        cout<<area(r);
    }
    return 0;
}
