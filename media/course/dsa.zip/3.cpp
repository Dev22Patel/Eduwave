#include <iostream>
#include<cstring>
using namespace std;
int main()
{
/* Enter your code here. Read input from STDIN. Print output to STDOUT */
    string str1;
    getline(cin,str1);
    int n;
    cin>>n;
    string str2;
    //cin>>str2;
    getchar();
    getline(cin,str2);
    //cout<<str2;
    int count=0;
    string temp;
    temp=str1;
    for(int i=0;i<n;i++)
    {
        str1+=temp;
    }
    for(int j=0;j<(int)str1.length();j++)
    {
        if((str1.substr(j,str2.length()))==str2)
        {
            count++;
        }
    }
    cout<<count;
    return 0;
}
