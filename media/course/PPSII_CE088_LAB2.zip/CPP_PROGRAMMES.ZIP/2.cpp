#include <iostream>

int & find_smaller(int& num1,int& num2)
{
  	if(num1>num2)
        return num2;
    else
        return num1;
}

int main() {

  	int num1, num2;
	std::cin >> num1 >> num2;

    find_smaller(num1, num2)*=2;

  	if(num1 > num2)
      	std::cout << num1;
  	else
      	std::cout << num2;

    return 0;
}
