#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


int main()
{
    int n,num,odd=0;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>num;
        odd^=num;
    }
    cout<<odd;
    return 0;
}
