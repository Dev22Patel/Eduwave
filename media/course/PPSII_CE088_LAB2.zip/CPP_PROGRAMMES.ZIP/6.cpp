#include <string>
#include <iostream>
#include<cctype>
using namespace std;


int main()
{
    string a;
    string b;
    while(cin>>a)
    {
        if(a[0]>=97 && a[0]<=122)
            a[0]-=32;
        b+=a+" ";
    }
    cout<<b;
    return 0;
}
