#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;
int main()
{
    long long int n;
    cin>>n;
    int step=0;
    while(1)
    {
        if(n==1)
        {
            break;
        }
        if(n%2!=0)
        {
            if((n-1)%4==0 || n==3)
            {
                n--;
            }
            else
            {
                n++;
            }
        }
        else
        {
            n/=2;
        }
        step++;
        if(n==1)
        {
            break;
        }
    }
    cout<<step;
    return 0;
}
