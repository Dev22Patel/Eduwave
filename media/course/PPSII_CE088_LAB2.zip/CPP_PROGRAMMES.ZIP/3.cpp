#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


int main()
{
    int n,i,j,z=0,total=0,t1,t2;
    cin>>n;
    int temp,k,t;
    vector<int> a,b;

    for(i=0;i<n;i++)
    {
        cin>>t1;
        a.push_back(t1);
        cin>>t2;
        b.push_back(t2);
    }
    cin>>t;
     for (i = 0; i<n; i++)
     {
        for (j = i + 1; j < n; j++)
        {
            if (a[i] < a[j])
            {
                temp = a[i];
                a[i] = a[j];
                a[j] = temp;
                temp = b[i];
                b[i] = b[j];
                b[j] = temp;
            }
        }
    }





    for(i=0;i<n;i++)
    {
        k=0;
        for(j=0;j>-1;j++)
        {
            if(b[i]>=k && total<=t)
            {
                total+=a[i];
                k++;
            }
            else
            {
                total-=a[i];
                k--;
                break;
            }
        }
         b[i]=k;
        if(k!=0)
        {
            z++;
        }

    }
    if(total!=t)
    {
        cout<<-1;
        return 0;
    }
    cout<<z<<endl;
    for(i=0;i<n;i++)
    {
        if(b[i]!=0)
            cout<<a[i]<<" "<<b[i]<<endl;
    }
    return 0;
}
